<?php

class Unirgy_SimpleLicense_Exception extends Exception
{

}